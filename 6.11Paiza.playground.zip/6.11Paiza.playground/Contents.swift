import UIKit

func Output(_ input:String){
    ////_を使って、Output("paiza")直接に入力することは可能になります
    ///文字列長さ
     let characterCount = input.count+2
      let stars = String(repeating: "+", count:characterCount)
    let input2:String = "+\(input)+"
    // 二つ方法がある
    //改行の書き方：（変数）\n　括弧で変数を囲む
    ////関数の戻り値,string
    ///\(input2)を文字列に変える
    print("\(stars)\n\(input2)\n\(stars)")
    // print(input)
    //  print(stars)
}
//let a = "paiza"
Output("paiza")
Output("TicTacToe")
