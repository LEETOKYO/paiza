import UIKit

let inputs1 = readLine()!.split(separator: " ").map { Int($0)! }
let n = inputs1[0]

var time1 = [Int]()
var time2 = [Int]()
var time3 = [Int]()

for _ in 1...n {
    let inputs2 = readLine()!.split(separator: " ").map { Int($0)! }
    time1.append(inputs2[0])
    time2.append(inputs2[1])
    time3.append(inputs2[2])
 
    
}
var daytime = 0
var daytimearray = [Int]()
for i in 0..<n {
    daytime = time1[i] + time2[i] + (24 - time3[i])
    daytimearray.append(daytime)
    }
    
if let min = daytimearray.min(), let max = daytimearray.max() {
    print(min)
    print(max)
} else {
    print("No values in the array.")
}

