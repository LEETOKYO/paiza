import UIKit
// 数列を使う解決方法
//from なしでも大丈夫だが、あると可読性が上がる
//関数の戻り値があれば、必ず型を指定する
//でも、直接に出力する場合には、いらない
func generateHandleName(name:String)-> String{
    let arr:[Character] = ["a", "e", "i", "o", "u", "A", "E", "I", "O", "U"]
    //文字列の定義と追加
    //初期化の空の文字列
    var handleName = ""
    for char in name {
        if  !arr.contains(char) {
            handleName.append(char)
        }
        
        }
    return handleName
    }
//新しい知識：集合
func generateHandleName2(from name:String)->String{
    let vowels:Set<Character> = ["a", "e", "i", "o", "u", "A", "E", "I", "O", "U"]
    var handleName = ""
    for char in name {
        if !vowels.contains(char){
            handleName.append(char)
        }
    }
    return handleName
}
//簡潔になってきます
func generateHandleName3(from name:String){
    let vowels:Set<Character> = ["a", "e", "i", "o", "u", "A", "E", "I", "O", "U"]
    var handleName = ""
    for char in name {
        if !vowels.contains(char){
            handleName.append(char)
        }
    }
   print(handleName)
}
//textのような感じがしてる
let name = "gdd"
let a = generateHandleName(name: name)
let a1 = generateHandleName2(from: name)
print(a)
print(a1)
let name2 = "aoisa"
let b = generateHandleName(name: name2)
let b2 = generateHandleName2(from: name2)
print(b)
print(b2)
generateHandleName3(from: name)
generateHandleName3(from: name2)
