import UIKit

var greeting = "Hello, playground"
//Swiftでは、関数定義において引数は_（アンダースコア）で始めることができます。これにより、関数を呼び出す際に引数名を省略できます。
//_がある場合には、funct convertleet(input:input1)必要がない;簡潔
//func convertLeet (_ input:String)->String{
func convertLeet ( input:String)->String{
    //文字列の定義、最初はブランク
    var leetString = ""
    for character in input {
        switch character{
        case "A" :
            leetString += "4"
        case "E" :
            leetString += "3"
        case "G" :
            leetString += "6"
        case "I" :
            leetString += "1"
        case "O" :
            leetString += "0"
        case "S" :
            leetString += "5"
        case "Z" :
            leetString += "2"
        default:
            leetString += String(character)
            
        }
    }
    return leetString
}
let input1 = "PAIZA"
//let leet1 = convertLeet(input1)
let leet1 = convertLeet(input:input1)
print(leet1)
let input2 = "ALANTURING"
//let leet2 = convertLeet(input2)
let leet2 = convertLeet(input:input2)
print(leet2)
