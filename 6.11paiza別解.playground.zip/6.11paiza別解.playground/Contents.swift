import UIKit

var greeting = "Hello, playground"
struct Output{
   var input: String = ""
  var count:Int = input.count+2
    //シンボルを連続して出力
    let stars = String(repeating:"*",count:count)
    let input2:String = "*\(input)*"
    func Print(){
        print("\(stars)\n\(input2)\n\(stars)")    }
}
var a = Output(input: "paiza")
print(a)
