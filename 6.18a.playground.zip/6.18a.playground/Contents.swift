import UIKit

var greeting = "Hello, playground"
func validateShiritori(words: [String]) -> String? {
    let count = words.count
    
    for i in 1..<(count - 1) {
        let currentWord = words[i]
        let nextWord = words[i + 1]
        
        guard let lastCharacter = currentWord.last, let firstCharacter = nextWord.first else {
            return nil
        }
        
        if lastCharacter.lowercased() != firstCharacter.lowercased() {
            return "\(lastCharacter) \(firstCharacter)"
        }
    }
    
    return "Yes"
}

// 使用例

let wordList = ["5",
                "idIOh",
                "hiKoQA",
                "AbijoD",
                "djgeldi",
                "kjoial"]

let result = validateShiritori(words: wordList)
if let output = result {
    print(output)
} else {
    print("しりとりが成立しませんでした")
}
