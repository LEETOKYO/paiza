import UIKit

var greeting = "Hello, playground"
func validateShiritori(words: [String]) -> String? {
    let count = words.count
    
    for i in 0..<(count - 1) {
        let currentWord = words[i]
        let nextWord = words[i + 1]
        
        guard let lastCharacter = currentWord.last, let firstCharacter = nextWord.first else {
            return nil
        }
        
        if lastCharacter.lowercased() != firstCharacter.lowercased() {
            return "\(lastCharacter) \(firstCharacter)"
        }
    }
    
    return "Yes"
}
// 使用例1
let wordList1 = ["apPle", "error", "suBway", "Zb"]
let result1 = validateShiritori(words: wordList1)
if let output1 = result1 {
    print(output1)
} else {
    print("しりとりが成立しませんでした")
}

// 使用例2
let wordList2 = ["idIOh", "hiKoQA", "AbijoD", "cjgeldi", "kjoial"]
let result2 = validateShiritori(words: wordList2)
if let output2 = result2 {
    print(output2)
} else {
    print("しりとりが成立しませんでした")
}

// 使用例3
let wordList3 = ["adia", "Akq", "qZR"]
let result3 = validateShiritori(words: wordList3)
if let output3 = result3 {
    print(output3)
} else {
    print("しりとりが成立しませんでした")
}
